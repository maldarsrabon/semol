document.addEventListener('DOMContentLoaded', () => {

  /* ===================== ASSETS ===================== */
  const SPECIMENS = [
    'assets/nft-01.png','assets/nft-02.png','assets/nft-03.png','assets/nft-04.png',
    'assets/nft-05.png','assets/nft-06.png','assets/nft-07.png','assets/nft-08.png',
    'assets/nft-09.png','assets/nft-10.png'
  ];

  /* ===================== BOOT SEQUENCE ===================== */
  const bootScreen = document.getElementById('boot-screen');
  const bootText = document.getElementById('boot-text');
  const bootMeterFill = document.getElementById('boot-meter-fill');
  const bootSub = document.getElementById('boot-sub');
  const skipBtn = document.getElementById('skip-boot');
  const site = document.getElementById('site');

  const FULL_TEXT = 'VYRO SUPPLY';
  const subLines = ['INITIALIZING CONTAINMENT FEED…', 'LOADING 5,555 SPECIMENS…', 'ACCESS GATE READY.'];
  let bootDone = false;

  function typeBoot(){
    let i = 0;
    const typeInterval = setInterval(() => {
      bootText.textContent = FULL_TEXT.slice(0, i + 1);
      i++;
      if (i >= FULL_TEXT.length){
        clearInterval(typeInterval);
        runMeter();
      }
    }, 90);
  }

  function runMeter(){
    let pct = 0;
    let subIdx = 0;
    bootSub.textContent = subLines[0];
    const meterInterval = setInterval(() => {
      pct += Math.random() * 9 + 4;
      if (pct > 100) pct = 100;
      bootMeterFill.style.width = pct + '%';
      const newSubIdx = pct > 66 ? 2 : pct > 30 ? 1 : 0;
      if (newSubIdx !== subIdx){ subIdx = newSubIdx; bootSub.textContent = subLines[subIdx]; }
      if (pct >= 100){
        clearInterval(meterInterval);
        setTimeout(revealSite, 350);
      }
    }, 90);
  }

  function revealSite(){
    if (bootDone) return;
    bootDone = true;
    bootScreen.classList.add('hidden');
    site.classList.add('revealed');
    document.body.classList.add('glitching');
    setTimeout(() => document.body.classList.remove('glitching'), 260);
  }

  skipBtn.addEventListener('click', revealSite);
  typeBoot();
  // Safety net in case something stalls
  setTimeout(revealSite, 6500);

  /* ===================== MARQUEE ===================== */
  const marqueeTrack = document.getElementById('marquee-track');
  const marqueeSet = [...SPECIMENS, ...SPECIMENS].map(src => {
    const img = document.createElement('img');
    img.src = src;
    img.alt = 'VYRO Supply specimen';
    return img;
  });
  marqueeSet.forEach(img => marqueeTrack.appendChild(img));

  /* ===================== SPECIMEN GALLERY ===================== */
  const grid = document.getElementById('specimens-grid');
  SPECIMENS.forEach((src, idx) => {
    const card = document.createElement('div');
    card.className = 'specimen-card';
    const img = document.createElement('img');
    img.src = src;
    img.alt = `VYRO Supply specimen #${idx + 1}`;
    img.loading = 'lazy';
    const tag = document.createElement('span');
    tag.className = 'specimen-tag';
    tag.textContent = '#' + String(idx + 1).padStart(4, '0');
    card.appendChild(img);
    card.appendChild(tag);
    grid.appendChild(card);
  });

  /* ===================== CLICK RIPPLE (motion on every click) ===================== */
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('.btn');
    if (!btn) return;
    const rect = btn.getBoundingClientRect();
    const ripple = document.createElement('span');
    const size = Math.max(rect.width, rect.height) * 1.2;
    ripple.className = 'ripple';
    ripple.style.width = ripple.style.height = size + 'px';
    ripple.style.left = (e.clientX - rect.left - size / 2) + 'px';
    ripple.style.top = (e.clientY - rect.top - size / 2) + 'px';
    btn.appendChild(ripple);
    setTimeout(() => ripple.remove(), 650);
  });

  /* ===================== APPLY MODAL / TASK FLOW ===================== */
  const overlay = document.getElementById('modal-overlay');
  const modal = document.getElementById('modal');
  const openBtn = document.getElementById('apply-open');
  const closeBtn = document.getElementById('modal-close');
  const doneBtn = document.getElementById('modal-done');
  const progressSteps = [...document.querySelectorAll('.modal-progress-step')];
  const stepPanels = [...document.querySelectorAll('.modal-step')];
  const walletForm = document.getElementById('wallet-form');
  const walletInput = document.getElementById('wallet-input');
  const walletError = document.getElementById('wallet-error');

  let currentStep = 1;

  function openModal(){
    overlay.classList.add('open');
    document.body.style.overflow = 'hidden';
    goToStep(1);
  }
  function closeModal(){
    overlay.classList.remove('open');
    document.body.style.overflow = '';
  }

  function goToStep(step){
    currentStep = step;
    stepPanels.forEach(p => p.classList.toggle('active', Number(p.dataset.step) === step));
    progressSteps.forEach(p => {
      const s = Number(p.dataset.step);
      p.classList.toggle('done', s < step);
      p.classList.toggle('current', s === step);
    });
  }

  openBtn.addEventListener('click', openModal);
  closeBtn.addEventListener('click', closeModal);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) closeModal(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });

  // Steps 1–3: follow / repost / comment
  document.querySelectorAll('.task-action').forEach(actionBtn => {
    actionBtn.addEventListener('click', function(){
      const taskNum = this.dataset.task;
      this.classList.add('done');
      const confirmBtn = document.querySelector(`.task-confirm[data-task="${taskNum}"]`);
      if (confirmBtn) confirmBtn.disabled = false;
    });
  });

  document.querySelectorAll('.task-confirm').forEach(confirmBtn => {
    confirmBtn.addEventListener('click', function(){
      if (this.disabled) return;
      const next = Number(this.dataset.task) + 1;
      goToStep(next);
    });
  });

  // Step 4: wallet submit
  walletForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const value = walletInput.value.trim();
    const isPlausible = value.length >= 6;
    if (!isPlausible){
      walletError.classList.add('show');
      walletInput.style.borderColor = 'var(--pink)';
      return;
    }
    walletError.classList.remove('show');
    goToStep(5);
  });

  walletInput.addEventListener('input', () => {
    walletError.classList.remove('show');
    walletInput.style.borderColor = '';
  });

  // Step 5: done
  doneBtn.addEventListener('click', closeModal);
});
